import joblib
import pandas as pd
from sklearn.preprocessing import StandardScaler

# Example data for scaling (use your actual dataset here)
data = pd.DataFrame({
    "metric1": [215630672],
    "metric2": [55],
    "metric3": [0],
    "metric4": [52],
    "metric5": [6],
    "metric6": [407438],
    "metric7": [0],
    "metric8": [0],
    "metric9": [7]
})

# Initialize and fit the scaler
scaler = StandardScaler()
scaler.fit(data)

# Save the scaler to a file
joblib.dump(scaler, 'models/scaler.pkl')

print("Scaler has been saved!")

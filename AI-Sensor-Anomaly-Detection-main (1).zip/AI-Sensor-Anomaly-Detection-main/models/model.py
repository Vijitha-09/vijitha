from sklearn.ensemble import RandomForestClassifier
import joblib
import pandas as pd

# Example training data (replace with your actual dataset)
data = pd.DataFrame({
    "metric1": [215630672, 123456789],
    "metric2": [55, 60],
    "metric3": [0, 1],
    "metric4": [52, 55],
    "metric5": [6, 7],
    "metric6": [407438, 407439],
    "metric7": [0, 1],
    "metric8": [0, 1],
    "metric9": [7, 8]
})

# Example target values
target = [0, 1]  # Replace with your actual target data

# Train the model
model = RandomForestClassifier()
model.fit(data, target)

# Save the model to a file
joblib.dump(model, 'models/your_model.pkl')

print("Model has been saved!")

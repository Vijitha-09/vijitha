import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import joblib

print("\n🚀 Starting Model Training...\n")

# Load anomaly-detected data
file_path = "C:/Users/VAISHU/IBM_Project/data/anomaly_detected_data.csv"
df = pd.read_csv(file_path)

# Convert 'Anomaly' column to numeric (0 = Normal, 1 = Anomaly)
df["Anomaly"] = df["Anomaly"].map({"Normal": 0, "Anomaly": 1})

# 🛠️ **Fix: Remove all non-numeric columns before training**
non_numeric_cols = df.select_dtypes(exclude=['float64', 'int64']).columns
df = df.drop(columns=non_numeric_cols)

# Select features and target variable
X = df.drop(["Anomaly"], axis=1)
y = df["Anomaly"]

# Split data into training and testing sets (80% train, 20% test)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train a Random Forest model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Save the trained model
model_file = "C:/Users/VAISHU/IBM_Project/models/anomaly_model.pkl"
joblib.dump(model, model_file)

print(f"✅ Model Training Complete! Model saved as '{model_file}'.")

import pandas as pd

print("🚀 Starting Data Cleaning...")

# Load the dataset
df = pd.read_csv("data\sensor_data.csv")

# Fill missing values with column mean
df.fillna(df.mean(numeric_only=True), inplace=True)

# Remove duplicate rows
df.drop_duplicates(inplace=True)

# Save cleaned data
df.to_csv("C:/Users/VAISHU/IBM_Project/data/cleaned_sensor_data.csv", index=False)

print("✅ Data Cleaning Done! Cleaned file saved as 'cleaned_sensor_data.csv'.")


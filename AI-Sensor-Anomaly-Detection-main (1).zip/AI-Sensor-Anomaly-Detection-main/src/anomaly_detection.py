import pandas as pd
from sklearn.ensemble import IsolationForest

print("\n🚀 Starting Anomaly Detection...\n")

# Load cleaned dataset
file_path = "C:/Users/VAISHU/IBM_Project/data/cleaned_sensor_data.csv"
df = pd.read_csv(file_path)

# Select only numerical columns for anomaly detection
num_cols = df.select_dtypes(include=['float64', 'int64']).columns
df_num = df[num_cols]

# Train Isolation Forest Model
model = IsolationForest(contamination=0.05, random_state=42)
df["Anomaly"] = model.fit_predict(df_num)

# Mark anomalies (-1 means anomaly, 1 means normal)
df["Anomaly"] = df["Anomaly"].map({1: "Normal", -1: "Anomaly"})

# Save results
output_file = "C:/Users/VAISHU/IBM_Project/data/anomaly_detected_data.csv"
df.to_csv(output_file, index=False)

print(f"✅ Anomaly Detection Complete! Results saved as '{output_file}'.")

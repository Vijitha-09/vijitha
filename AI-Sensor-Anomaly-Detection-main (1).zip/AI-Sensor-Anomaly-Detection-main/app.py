from flask import Flask, request, jsonify
import joblib
import pandas as pd

app = Flask(__name__)

# Load trained model
model = joblib.load("C:/Users/VAISHU/IBM_Project/models/anomaly_model.pkl")

# Get the exact feature names from the trained model
feature_columns = model.feature_names_in_.tolist()

@app.route("/predict", methods=["POST"])
def predict():
    try:
        # Get JSON data from request
        data = request.get_json()
        df = pd.DataFrame(data)

        # Ensure columns match training features exactly
        df = df[feature_columns]  # This will throw an error if features don't match

        # Convert all columns to correct data type (float)
        df = df.astype(float)

        # Predict anomalies
        predictions = model.predict(df)
        
        # Convert to readable labels
        results = ["Anomaly" if pred == 1 else "Normal" for pred in predictions]

        return jsonify({"predictions": results})

    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == "__main__":
    print("\n🚀 Flask API is running on http://127.0.0.1:5001 🚀\n")
    app.run(debug=True, port=5001)
